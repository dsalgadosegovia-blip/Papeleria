export type ProductType =
  | "Prenda"
  | "Tazón 11oz"
  | "Llavero Acrílico"
  | "Libreta"
  | "Agendas"
  | "Lanyards"
  | "Alcancías"
  | "Flyers"
  | "Tarjetas de Presentación";

export type OrderStatus =
  | "Pendiente"
  | "Validado"
  | "En Proceso"
  | "Listo para Retirar"
  | "Entregado";

export type QualityLabel = "EXCELENTE" | "ACEPTABLE" | "INSUFICIENTE";

export interface Order {
  id: string;
  clientName: string;
  clientPhone: string;
  productType: ProductType;
  productDetail: string;
  customText: string;
  font: string;
  size: string;
  imageQualityScore: number;
  imageQualityLabel: QualityLabel;
  qualityFeedback: string;
  deliveryMethod: "Retiro en Taller" | "Envío a Domicilio";
  deliveryCommune: string;
  deliveryAddress: string;
  deliveryCost: number;
  currentStatus: OrderStatus;
  isCameoCompatible: boolean;
  cutSpeed: number;
  pressure: number;
  createdAt: string;
  estimatedDelivery: string;
}

export interface AdminSettings {
  garmentLeadDays: number;
  mugLeadDays: number;
  keychainLeadDays: number;
  notebookLeadDays: number;
  extraLeadDays: number;
  workloadLevel: "Bajo" | "Medio" | "Alto";
  googleDriveEnabled: boolean;
  ownerPin: string;
}

export const DEFAULT_SETTINGS: AdminSettings = {
  garmentLeadDays: 5,
  mugLeadDays: 3,
  keychainLeadDays: 2,
  notebookLeadDays: 4,
  extraLeadDays: 0,
  workloadLevel: "Bajo",
  googleDriveEnabled: true,
  ownerPin: "1234",
};

export const PRODUCTS = [
  { id: "Prenda" as ProductType, emoji: "👕", label: "Poleras Beagle" },
  { id: "Tazón 11oz" as ProductType, emoji: "☕", label: "Tazones 11 oz" },
  { id: "Llavero Acrílico" as ProductType, emoji: "🔑", label: "Llaveros Acrílicos" },
  { id: "Libreta" as ProductType, emoji: "📓", label: "Libretas Portada" },
  { id: "Agendas" as ProductType, emoji: "📅", label: "Agendas Diarias" },
  { id: "Lanyards" as ProductType, emoji: "🎗️", label: "Cintas Lanyards" },
  { id: "Alcancías" as ProductType, emoji: "🪵", label: "Alcancías Madera" },
  { id: "Flyers" as ProductType, emoji: "📄", label: "Folletería Flyers" },
  { id: "Tarjetas de Presentación" as ProductType, emoji: "🪪", label: "Tarjetas Visita" },
];

export function getLeadDays(product: ProductType, settings: AdminSettings): number {
  const base = {
    "Prenda": settings.garmentLeadDays,
    "Tazón 11oz": settings.mugLeadDays,
    "Alcancías": settings.mugLeadDays,
    "Llavero Acrílico": settings.keychainLeadDays,
    "Lanyards": settings.keychainLeadDays,
    "Libreta": settings.notebookLeadDays,
    "Agendas": settings.notebookLeadDays,
    "Flyers": 2,
    "Tarjetas de Presentación": 2,
  }[product] ?? 2;
  return base + settings.extraLeadDays;
}

export function getDefaultDetail(product: ProductType): string {
  const map: Record<ProductType, string> = {
    "Prenda": "Polera Beagle Unisex, Talla M, Color Negro",
    "Tazón 11oz": "Tazón Blanco de Cerámica, 11 oz",
    "Llavero Acrílico": "Silueta contorno de mariposa, 5cm",
    "Libreta": "Hojas cuadriculadas, anillo metálico doble cero",
    "Agendas": "Agenda Diaria 2026, Diseño Universitario",
    "Lanyards": "Lanyard 2cm de ancho, broche desmontable",
    "Alcancías": "Alcancía de madera con tapa transparente",
    "Flyers": "100 Flyers impresos por una cara, papel couche brillo",
    "Tarjetas de Presentación": "100 Tarjetas laminadas mate, puntas redondeadas",
  };
  return map[product];
}
