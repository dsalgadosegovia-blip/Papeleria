import { NextRequest, NextResponse } from "next/server";
import { Order } from "@/lib/types";

// In-memory store (resets on cold start — replace with DB for production)
let orders: Order[] = [];

export async function GET() {
  return NextResponse.json(orders);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const order: Order = {
    ...body,
    id: `ORD-${Date.now()}`,
    currentStatus: "Pendiente",
    createdAt: new Date().toISOString(),
  };
  orders.unshift(order);
  return NextResponse.json(order, { status: 201 });
}

export async function PATCH(req: NextRequest) {
  const { id, status } = await req.json();
  const order = orders.find((o) => o.id === id);
  if (!order) return NextResponse.json({ error: "Not found" }, { status: 404 });
  order.currentStatus = status;
  return NextResponse.json(order);
}
