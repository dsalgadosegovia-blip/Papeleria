import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { imageBase64, productType, customText, width, height } = await req.json();

  const pixelCount = (width ?? 0) * (height ?? 0);

  // Local fallback scoring
  let score = pixelCount === 0 ? 95 : pixelCount < 300000 ? 45 : pixelCount < 1000000 ? 75 : 98;
  let label = score < 60 ? "INSUFICIENTE" : score < 85 ? "ACEPTABLE" : "EXCELENTE";
  let feedback =
    pixelCount === 0
      ? "Sin imagen adjunta. Se asume diseño de texto en alta calidad."
      : pixelCount < 300000
      ? `⚠️ Resolución baja (${width}x${height}px). Los bordes saldrán pixelados. Sube al menos 1200x1200px.`
      : pixelCount < 1000000
      ? `Resolución aceptable (${width}x${height}px). Evita estirar la imagen.`
      : `Excelente resolución (${width}x${height}px). Calidad ideal para imprenta.`;

  const isCameo = ["Llavero Acrílico", "Prenda", "Lanyards", "Alcancías"].includes(productType);
  const cutSpeed = productType === "Llavero Acrílico" ? 5 : 4;
  const pressure = productType === "Llavero Acrílico" ? 28 : productType === "Alcancías" ? 12 : 10;

  const apiKey = process.env.GEMINI_API_KEY ?? "";
  if (apiKey && apiKey.length > 10 && imageBase64) {
    try {
      const prompt = `Eres asistente de control de calidad para Danipapelería. Analiza:
- Producto: ${productType}
- Texto: "${customText}"
- Resolución: ${width}x${height}px
Responde SOLO en JSON: {"score":INT,"label":"EXCELENTE|ACEPTABLE|INSUFICIENTE","feedback":"...","isCameoCompatible":BOOL,"cutSpeedAdjustment":INT,"pressureAdjustment":INT}`;

      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }, { inlineData: { mimeType: "image/jpeg", data: imageBase64 } }] }],
            generationConfig: { responseMimeType: "application/json", temperature: 0.1 },
          }),
        }
      );
      if (res.ok) {
        const data = await res.json();
        const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
        const parsed = JSON.parse(text.replace(/```json|```/g, "").trim());
        return NextResponse.json({
          score: parsed.score ?? score,
          label: parsed.label ?? label,
          feedback: parsed.feedback ?? feedback,
          isCameoCompatible: parsed.isCameoCompatible ?? isCameo,
          cutSpeed: parsed.cutSpeedAdjustment ?? cutSpeed,
          pressure: parsed.pressureAdjustment ?? pressure,
        });
      }
    } catch { /* fall through to local */ }
  }

  return NextResponse.json({ score, label, feedback, isCameoCompatible: isCameo, cutSpeed, pressure });
}
