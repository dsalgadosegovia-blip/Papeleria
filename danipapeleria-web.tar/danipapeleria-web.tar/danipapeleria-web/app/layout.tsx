import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Danipapelería — Encargos Personalizados",
  description: "Pide tus productos personalizados: poleras, tazones, llaveros, libretas y más.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
