"use client";
import { useState, useEffect, useRef } from "react";
import {
  Sun, Settings, User, Send, MapPin, Store, Truck,
  CheckCircle, XCircle, ChevronDown, ChevronUp,
  RefreshCw, Lock, LayoutDashboard, Scissors, SlidersHorizontal, Image as ImageIcon
} from "lucide-react";
import { PRODUCTS, DEFAULT_SETTINGS, getLeadDays, getDefaultDetail, type Order, type ProductType, type AdminSettings, type OrderStatus } from "@/lib/types";

const C = {
  gold:"#F5A623",goldLight:"#FDE68A",goldCream:"#FFF8E7",
  chocoDark:"#3E2723",chocoPrimary:"#5D4037",chocoLight:"#8D6E63",
  cream:"#FFF9F0",surfaceGold:"#FFF3CD",
  warn:"#FF9800",success:"#4CAF50",info:"#2196F3",pending:"#FF5722",
};

const FONTS=[
  {id:"sans",label:"Sans Moderno",css:"font-sans",emoji:"📱",desc:"Limpia y legible."},
  {id:"serif",label:"Serif Clásico",css:"font-serif",emoji:"📖",desc:"Elegante, ideal para agendas."},
  {id:"cursive",label:"Script Manuscrito",css:"",emoji:"✍️",desc:"Cálido y artístico."},
  {id:"mono",label:"Retro Rústico",css:"font-mono",emoji:"💾",desc:"Look vintage."},
];
const SIZES=[
  {id:"small",label:"Pequeña",scale:0.75},
  {id:"medium",label:"Mediana",scale:1.0},
  {id:"large",label:"Grande",scale:1.35},
  {id:"xlarge",label:"Muy Grande",scale:1.7},
];

function getSuggestedStyle(p:ProductType){
  const fontMap:Partial<Record<ProductType,string>>={"Tazón 11oz":"cursive","Agendas":"serif","Libreta":"serif","Tarjetas de Presentación":"sans","Lanyards":"sans"};
  const sizeMap:Partial<Record<ProductType,string>>={"Prenda":"xlarge","Agendas":"large","Libreta":"large","Tarjetas de Presentación":"small","Lanyards":"small"};
  return {font:fontMap[p]??"sans", size:sizeMap[p]??"medium"};
}
function addDays(n:number){
  const d=new Date();d.setDate(d.getDate()+n);
  return d.toLocaleDateString("es-CL",{day:"numeric",month:"long",year:"numeric"});
}

function ProductMockup({product,text,font,size,imageUrl}:{product:ProductType;text:string;font:string;size:string;imageUrl?:string}){
  const s=SIZES.find(x=>x.id===size)??SIZES[1];
  const f=FONTS.find(x=>x.id===font)??FONTS[0];
  const fs=Math.round(13*s.scale);
  const fontStyle=font==="cursive"?{fontFamily:"cursive"}:{};
  const cls=`${f.css} font-bold text-center`;
  if(product==="Prenda")return(
    <div className="relative flex items-center justify-center" style={{width:140,height:160}}>
      <svg viewBox="0 0 140 160" width="140" height="160">
        <path d="M49,24 Q70,34 91,24 L115,32 L133,60 L119,70 L112,52 L112,136 L28,136 L28,52 L21,70 L7,60 L25,32 Z" fill="#E0E0E0" stroke="#BDBDBD" strokeWidth="2"/>
      </svg>
      <div className="absolute flex flex-col items-center gap-1" style={{top:55,width:72}}>
        {imageUrl&&<img src={imageUrl} className="rounded object-cover" style={{width:44,height:44}}/>}
        <span className={cls} style={{fontSize:fs,color:C.chocoDark,...fontStyle,lineHeight:1.2,maxWidth:68,overflow:"hidden"}}>{text||"Tu texto"}</span>
      </div>
    </div>
  );
  if(product==="Tazón 11oz")return(
    <div className="relative flex items-center justify-center" style={{width:130,height:130}}>
      <svg viewBox="0 0 130 130" width="130" height="130">
        <rect x="32" y="32" width="65" height="68" rx="8" fill="#FAFAFA" stroke="#CCC" strokeWidth="2"/>
        <ellipse cx="64" cy="32" rx="32" ry="7" fill="#EEE" stroke="#CCC" strokeWidth="2"/>
        <path d="M97,42 a14,18 0 0,1 0,36" fill="none" stroke="#DDD" strokeWidth="12"/>
      </svg>
      <div className="absolute flex flex-col items-center gap-1" style={{top:46,width:56}}>
        {imageUrl&&<img src={imageUrl} className="rounded" style={{width:30,height:30,objectFit:"cover"}}/>}
        <span className={cls} style={{fontSize:Math.round(11*s.scale),color:C.chocoDark,...fontStyle}}>{text||"Tu texto"}</span>
      </div>
    </div>
  );
  if(product==="Tarjetas de Presentación")return(
    <div className="rounded-xl flex flex-col justify-between p-3" style={{width:200,height:110,background:`linear-gradient(135deg,${C.chocoDark},${C.chocoPrimary})`,border:`1px solid ${C.gold}`}}>
      <div className="flex justify-between"><span style={{color:C.gold,fontSize:8,fontWeight:700}}>🌻 Danipapelería</span><span style={{color:"rgba(255,255,255,0.5)",fontSize:7}}>PREMIUM</span></div>
      <span className={cls} style={{fontSize:Math.round(12*s.scale),color:C.gold,...fontStyle}}>{text||"Tu nombre"}</span>
      <div className="flex justify-between"><span style={{color:"rgba(255,255,255,0.3)",fontSize:6}}>Tarjeta Corporativa</span><span style={{color:C.gold,fontSize:6}}>danipapeleria.cl</span></div>
    </div>
  );
  if(product==="Libreta"||product==="Agendas")return(
    <div className="relative rounded-lg flex items-center justify-center" style={{width:90,height:120,background:C.chocoDark,border:`1px solid ${C.gold}`}}>
      <div className="absolute left-0 top-0 bottom-0 w-3 flex flex-col justify-around items-center py-2">
        {[...Array(6)].map((_,i)=><div key={i} className="rounded-full" style={{width:7,height:7,border:`2px solid ${C.chocoLight}`}}/>)}
      </div>
      <div className="flex flex-col items-center gap-1 px-4">
        <span style={{color:C.gold,fontSize:6,letterSpacing:2}}>AGENDA</span>
        <span className={cls} style={{fontSize:Math.round(12*s.scale),color:"white",...fontStyle,textAlign:"center"}}>{text||"Tu texto"}</span>
      </div>
    </div>
  );
  return(
    <div className="relative rounded-xl flex items-center justify-center" style={{width:130,height:100,background:"#E0F2F1",border:"1px solid #009688"}}>
      <span className={cls} style={{fontSize:Math.round(12*s.scale),color:"#880E4F",...fontStyle,background:"rgba(255,255,255,0.85)",borderRadius:4,padding:"2px 8px"}}>{text||"Tu texto"}</span>
    </div>
  );
}

function QualityBadge({label}:{label:string}){
  const m:Record<string,{c:string,bg:string}>={EXCELENTE:{c:C.success,bg:"#E8F5E9"},ACEPTABLE:{c:C.warn,bg:"#FFF8E1"},INSUFICIENTE:{c:"#F44336",bg:"#FFEBEE"}};
  const s=m[label]??m.ACEPTABLE;
  return<span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{color:s.c,background:s.bg,border:`1px solid ${s.c}`}}>{label}</span>;
}
function StatusBadge({status}:{status:OrderStatus}){
  const m:Record<string,string>={Pendiente:C.pending,Validado:C.success,"En Proceso":C.info,"Listo para Retirar":C.success,Entregado:C.chocoLight};
  const color=m[status]??C.chocoLight;
  return<span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{color,background:`${color}22`,border:`1px solid ${color}`}}>{status}</span>;
}
function SectionTitle({n,title}:{n:string;title:string}){
  return(
    <div className="flex items-center gap-2 mb-3">
      <span className="w-7 h-7 rounded-full flex items-center justify-center text-sm font-bold" style={{background:C.gold,color:C.chocoDark}}>{n}</span>
      <span className="font-bold text-sm" style={{color:C.chocoPrimary}}>{title}</span>
    </div>
  );
}
function Card({children,className="",style={}}:{children:React.ReactNode;className?:string;style?:React.CSSProperties}){
  return<div className={`rounded-xl p-4 ${className}`} style={{background:"white",border:`1px solid ${C.goldLight}`,boxShadow:"0 2px 8px rgba(62,39,35,0.06)",...style}}>{children}</div>;
}

function CustomerForm({settings,onOrderPlaced}:{settings:AdminSettings;onOrderPlaced:(o:Order)=>void}){
  const[product,setProduct]=useState<ProductType>("Prenda");
  const[name,setName]=useState("");
  const[phone,setPhone]=useState("");
  const[detail,setDetail]=useState(getDefaultDetail("Prenda"));
  const[customText,setCustomText]=useState("");
  const[font,setFont]=useState("sans");
  const[size,setSize]=useState("medium");
  const[delivery,setDelivery]=useState(false);
  const[commune,setCommune]=useState("Pedro Aguirre Cerda");
  const[address,setAddress]=useState("");
  const[imgUrl,setImgUrl]=useState<string>();
  const[imgBase64,setImgBase64]=useState<string>();
  const[imgDims,setImgDims]=useState({w:0,h:0});
  const[quality,setQuality]=useState<{score:number;label:string;feedback:string}|null>(null);
  const[validating,setValidating]=useState(false);
  const[submitting,setSubmitting]=useState(false);
  const[success,setSuccess]=useState<Order|null>(null);
  const fileRef=useRef<HTMLInputElement>(null);

  useEffect(()=>{setDetail(getDefaultDetail(product));const s=getSuggestedStyle(product);setFont(s.font);setSize(s.size);},[product]);

  const deliveryCost=!delivery?0:commune==="Pedro Aguirre Cerda"?2000:commune==="RM"?4000:0;
  const leadDays=getLeadDays(product,settings);

  const handleImage=(file:File)=>{
    const reader=new FileReader();
    reader.onload=(e)=>{
      const dataUrl=e.target?.result as string;
      setImgUrl(dataUrl);
      const base64=dataUrl.split(",")[1];
      setImgBase64(base64);
      const img=new window.Image();
      img.onload=async()=>{
        const w=img.naturalWidth,h=img.naturalHeight;
        setImgDims({w,h});
        setValidating(true);
        const res=await fetch("/api/validate-image",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({imageBase64:base64,productType:product,customText,width:w,height:h})});
        setQuality(await res.json());
        setValidating(false);
      };
      img.src=dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const submit=async()=>{
    if(!name||!phone){alert("Ingresa nombre y teléfono");return;}
    setSubmitting(true);
    const res=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
      clientName:name,clientPhone:phone,productType:product,
      productDetail:`${detail} [${FONTS.find(f2=>f2.id===font)?.label}, ${SIZES.find(s2=>s2.id===size)?.label}]`,
      customText,font,size,
      imageQualityScore:quality?.score??95,imageQualityLabel:quality?.label??"EXCELENTE",qualityFeedback:quality?.feedback??"Sin imagen.",
      deliveryMethod:delivery?"Envío a Domicilio":"Retiro en Taller",
      deliveryCommune:delivery?commune:"",deliveryAddress:delivery?address:"",deliveryCost,
      isCameoCompatible:["Llavero Acrílico","Prenda","Lanyards","Alcancías"].includes(product),
      cutSpeed:4,pressure:10,
      estimatedDelivery:new Date(Date.now()+leadDays*86400000).toISOString(),
    })});
    const order=await res.json();
    setSubmitting(false);setSuccess(order);onOrderPlaced(order);
  };

  if(success)return(
    <div className="flex flex-col items-center gap-4 py-12">
      <CheckCircle size={64} style={{color:C.success}}/>
      <h2 className="text-2xl font-bold" style={{color:C.chocoDark}}>¡Pedido Registrado!</h2>
      <p className="text-sm text-center" style={{color:C.chocoPrimary}}>Pedido <strong>{success.id}</strong> para <strong>{success.clientName}</strong></p>
      <p className="text-sm" style={{color:C.chocoLight}}>Entrega estimada: {addDays(leadDays)}</p>
      <button className="px-6 py-2 rounded-lg font-bold mt-2" style={{background:C.gold,color:C.chocoDark}} onClick={()=>setSuccess(null)}>Nuevo Pedido</button>
    </div>
  );

  return(
    <div className="flex flex-col gap-5 pb-10">
      <Card style={{background:C.surfaceGold,border:`1px solid ${C.gold}`}}>
        <div className="flex items-center gap-3">
          <div className="flex-1"><h2 className="font-bold text-lg" style={{color:C.chocoDark}}>¡Diseña tu Producto Ideal!</h2><p className="text-xs mt-1" style={{color:C.chocoPrimary}}>Sube tus fotos, validamos la calidad al instante y sincronizamos con Drive de Dani.</p></div>
          <span className="text-4xl">🌻</span>
        </div>
      </Card>

      <div><SectionTitle n="1" title="Tus Datos de Contacto"/>
        <Card><div className="flex flex-col gap-3">
          {[["Nombre Completo","text",name,setName,"Ej. Daniela Salgado"],["Teléfono Whatsapp","tel",phone,setPhone,"Ej. +56 9 9988 7766"]].map(([label,type,val,fn,ph])=>(
            <div key={label as string}><label className="text-xs font-semibold mb-1 block" style={{color:C.chocoPrimary}}>{label as string}</label>
            <input type={type as string} value={val as string} onChange={e=>(fn as (v:string)=>void)(e.target.value)} placeholder={ph as string} className="w-full rounded-lg px-3 py-2 text-sm outline-none" style={{border:`1px solid ${C.goldLight}`,background:C.cream}}/></div>
          ))}
        </div></Card>
      </div>

      <div><SectionTitle n="2" title="Selecciona el Producto"/>
        <div className="grid grid-cols-3 gap-2">
          {PRODUCTS.map(p=>(
            <button key={p.id} onClick={()=>setProduct(p.id)} className="flex flex-col items-center justify-center rounded-xl p-2 h-20 transition-all" style={{background:product===p.id?C.gold:"white",border:`2px solid ${product===p.id?C.chocoDark:C.goldLight}`,color:product===p.id?C.chocoDark:C.chocoPrimary}}>
              <span className="text-2xl">{p.emoji}</span><span className="text-xs font-bold text-center leading-tight mt-1">{p.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div><SectionTitle n="3" title="Detalles de Personalización"/>
        <Card><div className="flex flex-col gap-3">
          {[["Especificaciones",detail,setDetail,"Ej. Talla / Material"],["Texto a estampar",customText,setCustomText,"Ej. 'Generación 2026'"]].map(([label,val,fn,ph])=>(
            <div key={label as string}><label className="text-xs font-semibold mb-1 block" style={{color:C.chocoPrimary}}>{label as string}</label>
            <input value={val as string} onChange={e=>(fn as (v:string)=>void)(e.target.value)} placeholder={ph as string} className="w-full rounded-lg px-3 py-2 text-sm" style={{border:`1px solid ${C.goldLight}`,background:C.cream}}/></div>
          ))}
          <div><p className="text-xs font-bold mb-2" style={{color:C.chocoPrimary}}>✍️ Tipo de letra:</p>
            <div className="flex flex-col gap-1.5">
              {FONTS.map(f2=>(
                <button key={f2.id} onClick={()=>setFont(f2.id)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-left transition-all" style={{background:font===f2.id?`${C.gold}22`:"transparent",border:`1px solid ${font===f2.id?C.gold:C.goldLight}`}}>
                  <span>{f2.emoji}</span><div><span className="text-xs font-bold block" style={{color:C.chocoDark}}>{f2.label}</span><span className="text-xs" style={{color:C.chocoLight}}>{f2.desc}</span></div>
                  {font===f2.id&&<CheckCircle size={14} style={{color:C.gold,marginLeft:"auto"}}/>}
                </button>
              ))}
            </div>
          </div>
          <div><p className="text-xs font-bold mb-2" style={{color:C.chocoPrimary}}>📐 Tamaño:</p>
            <div className="grid grid-cols-4 gap-1.5">
              {SIZES.map(sz=>(
                <button key={sz.id} onClick={()=>setSize(sz.id)} className="py-2 px-1 rounded-xl text-xs font-bold transition-all" style={{background:size===sz.id?C.chocoDark:"transparent",color:size===sz.id?C.gold:C.chocoPrimary,border:`1px solid ${size===sz.id?C.chocoDark:C.goldLight}`}}>{sz.label}</button>
              ))}
            </div>
          </div>
        </div></Card>
      </div>

      <div><SectionTitle n="🎨" title="Vista Previa"/>
        <Card><div className="flex flex-col items-center gap-3">
          <div className="flex items-center justify-center rounded-xl p-4" style={{background:C.cream,border:`1px solid ${C.goldLight}`,minHeight:160}}>
            <ProductMockup product={product} text={customText||"Tu texto"} font={font} size={size} imageUrl={imgUrl}/>
          </div>
          <p className="text-xs text-center" style={{color:C.chocoLight}}>MOCKUP DE REFERENCIA — Diseño definitivo se coordina con Dani.</p>
        </div></Card>
      </div>

      <div><SectionTitle n="4" title="Sube tu Foto de Diseño"/>
        <Card>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e=>e.target.files?.[0]&&handleImage(e.target.files[0])}/>
          <div onClick={()=>fileRef.current?.click()} className="flex flex-col items-center justify-center rounded-xl p-6 cursor-pointer transition-all hover:opacity-80" style={{border:`2px dashed ${C.gold}`,background:C.goldCream,minHeight:100}}>
            {imgUrl?(
              <div className="flex items-center gap-3">
                <img src={imgUrl} className="w-16 h-16 rounded-lg object-cover" style={{border:`1px solid ${C.goldLight}`}}/>
                <div>
                  <p className="text-sm font-bold" style={{color:C.success}}>✓ Imagen cargada</p>
                  <p className="text-xs" style={{color:C.chocoLight}}>{imgDims.w}×{imgDims.h}px</p>
                  <button className="text-xs underline mt-1" style={{color:C.chocoPrimary}} onClick={e=>{e.stopPropagation();setImgUrl(undefined);setQuality(null);}}>Quitar</button>
                </div>
              </div>
            ):(
              <><ImageIcon size={28} style={{color:C.chocoLight}}/><p className="text-sm font-bold mt-2" style={{color:C.chocoDark}}>Presiona para subir foto</p><p className="text-xs" style={{color:C.chocoLight}}>JPEG, PNG • Máx 20MB</p></>
            )}
          </div>
          {validating&&<p className="text-xs text-center mt-2 animate-pulse" style={{color:C.chocoPrimary}}>Analizando calidad con IA…</p>}
          {quality&&!validating&&(
            <div className="mt-3 rounded-lg p-3" style={{background:quality.label==="INSUFICIENTE"?"#FFEBEE":quality.label==="ACEPTABLE"?"#FFF8E1":"#E8F5E9",border:`1px solid ${quality.label==="INSUFICIENTE"?"#F44336":quality.label==="ACEPTABLE"?C.warn:C.success}`}}>
              <div className="flex items-center gap-2 mb-1">
                {quality.label==="INSUFICIENTE"?<XCircle size={14} style={{color:"#F44336"}}/>:<CheckCircle size={14} style={{color:C.success}}/>}
                <span className="text-xs font-bold" style={{color:C.chocoDark}}>Calidad: {quality.score}/100</span>
                <QualityBadge label={quality.label}/>
              </div>
              <p className="text-xs" style={{color:C.chocoPrimary}}>{quality.feedback}</p>
            </div>
          )}
        </Card>
      </div>

      <div><SectionTitle n="5" title="Forma de Entrega"/>
        <Card>
          <div className="grid grid-cols-2 gap-2 mb-4">
            {[{v:false,icon:<Store size={14}/>,label:"Retiro en Taller"},{v:true,icon:<Truck size={14}/>,label:"Envío Domicilio"}].map(opt=>(
              <button key={String(opt.v)} onClick={()=>setDelivery(opt.v)} className="flex items-center justify-center gap-2 rounded-lg py-2.5 font-bold text-sm transition-all" style={{background:delivery===opt.v?C.chocoPrimary:"white",color:delivery===opt.v?"white":C.chocoPrimary,border:`1px solid ${C.chocoPrimary}`}}>
                {opt.icon}{opt.label}
              </button>
            ))}
          </div>
          {!delivery&&<p className="text-xs rounded-lg p-2" style={{background:C.surfaceGold,color:C.chocoDark}}>📍 Retiras gratis en nuestro taller en Pedro Aguirre Cerda.</p>}
          {delivery&&(
            <div className="flex flex-col gap-3">
              {[["Pedro Aguirre Cerda","Pedro Aguirre Cerda","$2.000 CLP"],["RM","Región Metropolitana","$4.000 CLP"],["Regiones","Otras Regiones","Por pagar (Starken)"]].map(([v,label,cost])=>(
                <label key={v} className="flex items-start gap-2 cursor-pointer p-2 rounded-lg" style={{background:commune===v?C.surfaceGold:"transparent"}}>
                  <input type="radio" checked={commune===v} onChange={()=>setCommune(v)} style={{accentColor:C.gold,marginTop:2}}/>
                  <div><span className="text-sm font-bold block" style={{color:C.chocoDark}}>{label}</span><span className="text-xs" style={{color:C.chocoPrimary}}>{cost}</span></div>
                </label>
              ))}
              <div><label className="text-xs font-semibold mb-1 block" style={{color:C.chocoPrimary}}>Dirección</label>
                <input value={address} onChange={e=>setAddress(e.target.value)} placeholder="Ej. Av. Club de la Unión 1234" className="w-full rounded-lg px-3 py-2 text-sm" style={{border:`1px solid ${C.goldLight}`,background:C.cream}}/>
              </div>
              <a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address+" "+commune+" Santiago Chile")}`} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-bold" style={{background:"#1976D2",color:"white"}}>
                <MapPin size={14}/>Validar en Google Maps
              </a>
            </div>
          )}
        </Card>
      </div>

      <Card style={{background:C.chocoPrimary,border:"none"}}>
        <h3 className="font-bold text-base mb-3" style={{color:C.gold}}>Resumen del Encargo</h3>
        <div className="flex flex-col gap-1.5 mb-4">
          {[["Producto:",product],["Despacho:",deliveryCost===0&&!delivery?"Gratis (retiro)":commune==="Regiones"?"Por pagar":`$${deliveryCost.toLocaleString("es-CL")} CLP`],["Plazo:",`${leadDays} días hábiles`],["Entrega:",addDays(leadDays)]].map(([k,v])=>(
            <div key={k} className="flex justify-between text-sm"><span style={{color:C.goldLight}}>{k}</span><span className="font-bold" style={{color:"white"}}>{v}</span></div>
          ))}
        </div>
        <button onClick={submit} disabled={submitting} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-base transition-all" style={{background:C.gold,color:C.chocoDark,opacity:submitting?0.7:1}}>
          {submitting?<RefreshCw size={18} className="animate-spin"/>:<Send size={18}/>}
          {submitting?"Enviando…":"Solicitar Encargo Personalizado"}
        </button>
      </Card>
    </div>
  );
}

function AdminPanel({orders,settings,onSettingsChange,onStatusChange}:{orders:Order[];settings:AdminSettings;onSettingsChange:(s:AdminSettings)=>void;onStatusChange:(id:string,status:OrderStatus)=>void}){
  const[tab,setTab]=useState<"orders"|"cameo"|"config">("orders");
  const[filter,setFilter]=useState("TODOS");
  const[expanded,setExpanded]=useState<string|null>(null);
  const[localSettings,setLocalSettings]=useState(settings);
  const STATUSES:OrderStatus[]=["Pendiente","Validado","En Proceso","Listo para Retirar","Entregado"];
  const filtered=filter==="TODOS"?orders:orders.filter(o=>o.currentStatus===filter);
  const cameo=orders.filter(o=>o.isCameoCompatible);

  return(
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between px-3 py-2 rounded-xl" style={{background:C.chocoPrimary}}>
        <div><p className="text-xs font-bold" style={{color:"white"}}>Google Drive (Simulado)</p><p className="text-xs" style={{color:C.goldLight}}>dsalgadosegovia@gmail.com</p></div>
        <button className="text-xs font-bold px-3 py-1 rounded-lg" style={{background:C.gold,color:C.chocoDark}}>Forzar Sinc</button>
      </div>
      <div className="grid grid-cols-3 rounded-xl overflow-hidden" style={{border:`1px solid ${C.goldLight}`}}>
        {([["orders","Ver Estados",<LayoutDashboard key="ld" size={14}/>],["cameo","Cameo",<Scissors key="sc" size={14}/>],["config","Config",<SlidersHorizontal key="sl" size={14}/>]] as const).map(([id,label,icon])=>(
          <button key={id} onClick={()=>setTab(id)} className="flex flex-col items-center justify-center gap-0.5 py-2 text-xs font-bold transition-all" style={{background:tab===id?C.gold:C.cream,color:tab===id?C.chocoDark:C.chocoPrimary}}>
            {icon}{label}
          </button>
        ))}
      </div>

      {tab==="orders"&&(
        <div className="flex flex-col gap-3">
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {["TODOS",...STATUSES].map(f=>(
              <button key={f} onClick={()=>setFilter(f)} className="whitespace-nowrap text-xs font-bold px-3 py-1 rounded-lg flex-shrink-0" style={{background:filter===f?C.gold:C.cream,color:filter===f?C.chocoDark:C.chocoPrimary,border:`1px solid ${filter===f?C.chocoDark:C.goldLight}`}}>{f}</button>
            ))}
          </div>
          {filtered.length===0?<div className="text-center py-12 text-sm" style={{color:C.chocoLight}}>Sin pedidos en "{filter}"</div>:filtered.map(o=>(
            <Card key={o.id}>
              <div className="flex items-start justify-between mb-2 cursor-pointer" onClick={()=>setExpanded(expanded===o.id?null:o.id)}>
                <div>
                  <div className="flex items-center gap-2"><span className="font-bold text-sm" style={{color:C.chocoDark}}>{o.id}</span><span className="text-xs font-bold px-2 py-0.5 rounded" style={{background:C.chocoDark,color:C.gold}}>{o.productType}</span></div>
                  <p className="text-sm mt-0.5">{o.clientName} — {o.clientPhone}</p>
                </div>
                <div className="flex flex-col items-end gap-1"><StatusBadge status={o.currentStatus}/>{expanded===o.id?<ChevronUp size={14}/>:<ChevronDown size={14}/>}</div>
              </div>
              <div className="flex justify-between items-center"><span className="text-xs" style={{color:C.chocoLight}}>Calidad: {o.imageQualityScore}/100</span><QualityBadge label={o.imageQualityLabel}/></div>
              {expanded===o.id&&(
                <div className="mt-3 pt-3" style={{borderTop:`1px solid ${C.goldLight}`}}>
                  <div className="flex flex-col gap-1 mb-3 text-xs" style={{color:C.chocoPrimary}}>
                    <p><strong>Detalle:</strong> {o.productDetail}</p>
                    <p><strong>Texto:</strong> "{o.customText}"</p>
                    <p><strong>Entrega:</strong> {o.deliveryMethod}</p>
                    {o.deliveryMethod==="Envío a Domicilio"&&<p><strong>Dirección:</strong> {o.deliveryAddress}, {o.deliveryCommune} — ${o.deliveryCost.toLocaleString("es-CL")}</p>}
                    <p><strong>IA Feedback:</strong> {o.qualityFeedback}</p>
                  </div>
                  <p className="text-xs font-bold mb-1.5" style={{color:C.chocoDark}}>Cambiar estado:</p>
                  <div className="flex gap-1 flex-wrap">
                    {STATUSES.map(s=>(
                      <button key={s} disabled={o.currentStatus===s} onClick={()=>onStatusChange(o.id,s)} className="text-xs px-2 py-1 rounded-lg font-bold" style={{background:o.currentStatus===s?"#ccc":C.chocoPrimary,color:"white",opacity:o.currentStatus===s?0.5:1}}>{s}</button>
                    ))}
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      {tab==="cameo"&&(
        <div className="flex flex-col gap-3">
          <Card style={{background:C.surfaceGold}}><div className="flex items-center gap-2 mb-1"><Scissors size={16} style={{color:C.gold}}/><span className="font-bold text-sm">Silhouette Cameo</span></div><p className="text-xs" style={{color:C.chocoPrimary}}>Trazados listos para la máquina de corte.</p></Card>
          {cameo.length===0?<p className="text-center text-sm py-8" style={{color:C.chocoLight}}>No hay pedidos Cameo.</p>:cameo.map(o=>(
            <Card key={o.id}>
              <div className="flex justify-between mb-2"><span className="font-bold text-sm" style={{color:C.chocoDark}}>{o.id} — {o.productType}</span><span className="text-xs font-bold px-2 py-0.5 rounded" style={{background:"#E8F5E9",color:C.success}}>Listo Cameo</span></div>
              <p className="text-xs mb-2" style={{color:C.chocoPrimary}}>"{o.customText}"</p>
              <div className="grid grid-cols-3 gap-2 text-center rounded-lg py-2" style={{background:C.cream}}>
                {[["Velocidad",`${o.cutSpeed} s/m`],["Presión",`${o.pressure} gf`],["Calidad",`${o.imageQualityScore}/100`]].map(([l,v])=>(
                  <div key={l}><p className="text-xs" style={{color:C.chocoLight}}>{l}</p><p className="text-sm font-bold" style={{color:C.success}}>{v}</p></div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab==="config"&&(
        <div className="flex flex-col gap-4">
          <Card>
            <p className="font-bold text-sm mb-3" style={{color:C.chocoDark}}>Carga de Trabajo</p>
            <div className="grid grid-cols-3 gap-2">
              {(["Bajo","Medio","Alto"] as const).map(lvl=>(
                <button key={lvl} onClick={()=>setLocalSettings({...localSettings,workloadLevel:lvl,extraLeadDays:lvl==="Bajo"?0:lvl==="Medio"?2:5})} className="py-2 rounded-lg font-bold text-sm" style={{background:localSettings.workloadLevel===lvl?C.gold:C.cream,color:localSettings.workloadLevel===lvl?C.chocoDark:C.chocoPrimary,border:`1px solid ${C.goldLight}`}}>{lvl}</button>
              ))}
            </div>
            <p className="text-xs mt-2" style={{color:C.chocoLight}}>+{localSettings.extraLeadDays} días extra — Carga "{localSettings.workloadLevel}"</p>
          </Card>
          <Card>
            <p className="font-bold text-sm mb-3" style={{color:C.chocoDark}}>Días de Producción Base</p>
            <div className="grid grid-cols-2 gap-3">
              {([["Prendas","garmentLeadDays"],["Tazones","mugLeadDays"],["Llaveros","keychainLeadDays"],["Libretas","notebookLeadDays"]] as [string,keyof AdminSettings][]).map(([label,key])=>(
                <div key={key}><label className="text-xs font-semibold mb-1 block" style={{color:C.chocoPrimary}}>{label}</label>
                <input type="number" min={1} max={20} value={localSettings[key] as number} onChange={e=>setLocalSettings({...localSettings,[key]:Number(e.target.value)})} className="w-full rounded-lg px-3 py-2 text-sm text-center" style={{border:`1px solid ${C.goldLight}`,background:C.cream}}/></div>
              ))}
            </div>
          </Card>
          <button onClick={()=>onSettingsChange(localSettings)} className="w-full py-3 rounded-xl font-bold" style={{background:C.chocoPrimary,color:"white"}}>Guardar Configuración</button>
        </div>
      )}
    </div>
  );
}

export default function Page(){
  const[isAdmin,setIsAdmin]=useState(false);
  const[loggedIn,setLoggedIn]=useState(false);
  const[pin,setPin]=useState("");
  const[loginErr,setLoginErr]=useState("");
  const[orders,setOrders]=useState<Order[]>([]);
  const[settings,setSettings]=useState<AdminSettings>(DEFAULT_SETTINGS);
  const[rotation,setRotation]=useState(0);

  useEffect(()=>{const id=setInterval(()=>setRotation(r=>(r+1)%360),33);return()=>clearInterval(id);},[]);
  useEffect(()=>{if(isAdmin&&loggedIn){fetch("/api/orders").then(r=>r.json()).then(setOrders);}},[isAdmin,loggedIn]);

  const handleLogin=()=>{if(pin===settings.ownerPin){setLoggedIn(true);setLoginErr("");}else setLoginErr("PIN incorrecto");};
  const handleStatusChange=async(id:string,status:OrderStatus)=>{
    await fetch("/api/orders",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({id,status})});
    setOrders(prev=>prev.map(o=>o.id===id?{...o,currentStatus:status}:o));
  };

  return(
    <div className="min-h-screen" style={{background:C.cream}}>
      <div className="max-w-md mx-auto px-4">
        <header className="sticky top-0 z-20 py-3 mb-2" style={{background:C.cream,borderBottom:`1px solid ${C.goldLight}`}}>
          <div className="flex items-center gap-3">
            <div className="flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center cursor-pointer" style={{background:C.gold,border:`2px solid ${C.chocoDark}`,transform:`rotate(${rotation}deg)`}}>
              <Sun size={22} style={{color:C.chocoDark}}/>
            </div>
            <div className="flex-1">
              <h1 className="font-bold text-xl leading-none" style={{color:isAdmin?C.gold:C.chocoDark,fontFamily:"Georgia,serif"}}>Danipapelería</h1>
              <p className="text-xs" style={{color:C.chocoLight}}>{isAdmin?"PANEL DE CONTROL DANI":"Encargos Personalizados"}</p>
            </div>
            <button onClick={()=>{setIsAdmin(!isAdmin);if(isAdmin){setLoggedIn(false);setPin("");}}} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs" style={{background:isAdmin?C.chocoDark:C.gold,color:isAdmin?"white":C.chocoDark}}>
              {isAdmin?<><User size={13}/>Volver</>:<><Settings size={13}/>Admin</>}
            </button>
          </div>
        </header>
        <main className="py-2">
          {!isAdmin&&<CustomerForm settings={settings} onOrderPlaced={o=>setOrders(prev=>[o,...prev])}/>}
          {isAdmin&&!loggedIn&&(
            <div className="flex flex-col items-center gap-5 py-12">
              <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{background:`${C.gold}33`}}><Lock size={28} style={{color:C.gold}}/></div>
              <h2 className="text-xl font-bold" style={{color:C.chocoDark}}>Acceso Propietaria</h2>
              <Card className="w-full">
                <label className="text-xs font-semibold mb-1 block" style={{color:C.chocoPrimary}}>PIN de seguridad</label>
                <input type="password" value={pin} onChange={e=>setPin(e.target.value)} onKeyDown={e=>e.key==="Enter"&&handleLogin()} placeholder="Ingresa tu PIN" className="w-full rounded-lg px-3 py-2 text-sm text-center tracking-widest mb-3" style={{border:`1px solid ${loginErr?"#F44336":C.goldLight}`,background:C.cream}}/>
                {loginErr&&<p className="text-xs text-center mb-2" style={{color:"#F44336"}}>{loginErr}</p>}
                <button onClick={handleLogin} className="w-full py-2.5 rounded-lg font-bold" style={{background:C.gold,color:C.chocoDark}}>Entrar al Panel</button>
                <p className="text-xs text-center mt-2" style={{color:C.chocoLight}}>PIN por defecto: 1234</p>
              </Card>
            </div>
          )}
          {isAdmin&&loggedIn&&<AdminPanel orders={orders} settings={settings} onSettingsChange={setSettings} onStatusChange={handleStatusChange}/>}
        </main>
      </div>
    </div>
  );
}
